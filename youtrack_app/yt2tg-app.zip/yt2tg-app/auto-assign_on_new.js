/**
 * Автоматичне призначення виконавця при виході задачі зі статусу "Нова"
 * та відправка оновлення у Telegram через webhook.
 *
 * Працює тільки якщо змінився статус і попередній статус був "Нова" / "New".
 * Призначає ctx.currentUser, якщо виконавець порожній.
 */

var entities = require('@jetbrains/youtrack-scripting-api/entities');
var http = require('@jetbrains/youtrack-scripting-api/http');

exports.rule = entities.Issue.onChange({
  title: 'Автопризначення та відправка повідомлення після виходу зі "Нова"',

  guard: function (ctx) {
    var issue = ctx.issue;
    if (!issue || issue.becomesReported) return false;

    var stateChanged = issue.isChanged('State') || issue.isChanged('Статус');

    function prevName(fieldName) {
      try {
        var prev = issue.fields.oldValue(fieldName);
        return String((prev && (prev.name || prev.localizedName || prev.presentation)) || '').toLowerCase();
      } catch (e) { return ''; }
    }

    var prev = prevName('State') || prevName('Статус');
    var wasNew = prev === 'нова' || prev === 'new';

    return stateChanged && wasNew;
  },

  action: function (ctx) {
    var issue = ctx.issue;
    var me = ctx.currentUser;
    if (!me) return;

    // --- Утилітарні функції (винесені з try для уникнення ESLint-попереджень)
    var pickStatus = function (issue) {
      try { if (issue.fields['Статус'] && issue.fields['Статус'].name) return String(issue.fields['Статус'].name); } catch (e) {}
      try { if (issue.fields.State && issue.fields.State.name) return String(issue.fields.State.name); } catch (e) {}
      return '';
    };

    var pickAssigneeLabel = function (val) {
      if (!val) return '[не призначено]';
      if (Array.isArray(val)) {
        var names = [];
        for (var i = 0; i < val.length; i++) {
          var u = val[i];
          if (u && (u.fullName || u.login || u.name)) names.push(String(u.fullName || u.login || u.name));
        }
        return names.length ? names.join(', ') : '[не призначено]';
      }
      return String(val.fullName || val.login || val.name || '[не призначено]');
    };

    // --- Призначення виконавця, якщо не задано
    try {
      if (!issue.fields.Assignee && !issue.fields.Виконавець) {
        issue.fields.Assignee = me;
      }
    } catch (e1) {
      try { issue.fields['Виконавець'] = me; } catch (e2) {
        console.log('auto-assign: поле виконавця не знайдено');
        return;
      }
    }

    // --- Формування payload і відправка webhook
    try {
      var prjShort = (issue.project && (issue.project.shortName || issue.project.name)) || '';
      var computedId = issue.idReadable ||
        (prjShort && issue.numberInProject != null ? (prjShort + '-' + issue.numberInProject) : '') ||
        (issue.id != null ? String(issue.id) : '');

      var payload = {
        idReadable: computedId,
        summary: issue.summary || '',
        description: issue.description || '',
        url: issue.url || '',
        author: (issue.reporter && (issue.reporter.fullName || issue.reporter.login)) || '',
        status: pickStatus(issue),
        assignee: pickAssigneeLabel(issue.fields.Assignee || issue.fields.Виконавець),
        changes: ['auto-assigned']
      };

      var baseUrl = (ctx.settings.WEBHOOK_BASE || '').replace(/\/+$/, '');
      var secret = ctx.settings.WEBHOOK_SECRET;
      if (!baseUrl || !secret) {
        console.log('yt2tg-assign: missing baseUrl or secret');
        return;
      }

      var conn = new http.Connection(baseUrl);
      conn.addHeader('Content-Type', 'application/json');
      conn.bearerAuth(secret);

      var res = conn.postSync('/youtrack/update', [], JSON.stringify(payload));
      var code = (res && (res.status != null ? res.status : res.responseCode));
      console.log('yt2tg-assign: status=' + code);
    } catch (e) {
      console.log('yt2tg-assign: exception: ' + e);
    }
  },

  requirements: {}
});
