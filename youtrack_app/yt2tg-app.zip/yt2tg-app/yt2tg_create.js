var entities = require('@jetbrains/youtrack-scripting-api/entities');
var http = require('@jetbrains/youtrack-scripting-api/http');

exports.rule = entities.Issue.onChange({
  title: 'Issue created – sending webhook',

  // guard – правило спрацьовує тільки при створенні задачі
  guard: function (ctx) { return ctx.issue && ctx.issue.becomesReported; },

  action: function (ctx) {
    try {
      var issue = ctx.issue;

      // обчислення зручного ID задачі (наприклад, ID-123)
      var prjShort = (issue.project && (issue.project.shortName || issue.project.name)) || '';
      var computedId = issue.idReadable ||
        (prjShort && issue.numberInProject != null ? (prjShort + '-' + issue.numberInProject) : '') ||
        (issue.id != null ? String(issue.id) : '');

      // визначення автора (повне ім’я або логін)
      var author = (issue.reporter && (issue.reporter.fullName || issue.reporter.login)) || null;

      // визначення статусу (спочатку локалізоване поле)
      var status = null;
      try {
        var stLoc = issue.fields['Статус'];
        if (stLoc && stLoc.name) status = String(stLoc.name);
      } catch (e) {}
      if (!status) {
        try {
          var stSys = issue.fields.State;
          if (stSys && stSys.name) status = String(stSys.name);
        } catch (e) {}
      }

      // визначення виконавця (підтримка одиночних/множинних значень)
      function pickAssigneeLabel(val) {
        if (!val) return null;
        if (Array.isArray(val)) {
          var names = [];
          for (var i = 0; i < val.length; i++) {
            var u = val[i];
            if (u && (u.fullName || u.login || u.name)) {
              names.push(String(u.fullName || u.login || u.name));
            }
          }
          return names.length ? names.join(', ') : null;
        }
        return String(val.fullName || val.login || val.name || '');
      }

      var assignee = null;
      var assigneeKeys = ['Assignee', 'Assignees', 'Виконавець', 'Виконавці'];
      for (var k = 0; k < assigneeKeys.length && !assignee; k++) {
        try {
          var fld = issue.fields[assigneeKeys[k]];
          var label = pickAssigneeLabel(fld);
          if (label) assignee = label;
        } catch (e) {}
      }
      if (!assignee) assignee = '[не призначено]';

      // формування даних для вебхука
      var payload = {
        idReadable: computedId,
        summary: issue.summary || '',
        description: issue.description || '',
        url: issue.url || '',
        author: author || '',
        status: status || '',
        assignee: assignee
      };

      // відправлення даних у зовнішню систему
      var baseUrl = (ctx.settings.WEBHOOK_BASE || '').replace(/\/+$/, '');
      var secret  = ctx.settings.WEBHOOK_SECRET;
      if (!baseUrl || !secret) { console.log('yt2tg: missing baseUrl or secret'); return; }

      var conn = new http.Connection(baseUrl);
      conn.addHeader('Content-Type', 'application/json');
      conn.bearerAuth(secret);

      var res = conn.postSync('/youtrack', [], JSON.stringify(payload));
      var code = (res && (res.status != null ? res.status : res.responseCode));
      console.log('yt2tg: status=' + code + ' body=' + (res && String(res.response).slice(0,200)));

      // не блокуємо створення задачі навіть якщо вебхук не спрацював
    } catch (e) {
      console.log('yt2tg: exception: ' + e);
    }
  },

  requirements: {}
});
