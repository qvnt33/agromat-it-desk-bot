/**
 * YouTrack rule: "Issue created – sending webhook"
 *
 * Призначення: надсилати повний payload у Telegram через вебхук одразу після створення заявки.
 * Використовується окремий endpoint `/youtrack`.
 */

var entities = require('@jetbrains/youtrack-scripting-api/entities');
var http = require('@jetbrains/youtrack-scripting-api/http');

// Універсальна функція для перетворення об'єкта/масиву користувачів у рядок
var pickAssigneeLabel = function (val) {
  if (!val) return null;
  if (Array.isArray(val)) {
    var names = [];
    for (var i = 0; i < val.length; i++) {
      var u = val[i];
      if (u && (u.fullName || u.login || u.name)) names.push(String(u.fullName || u.login || u.name));
    }
    return names.length ? names.join(', ') : null;
  }
  return String(val.fullName || val.login || val.name || '');
};

exports.rule = entities.Issue.onChange({
  title: 'Issue created – sending webhook',

  // Триггер: заявка щойно стала видимою (тобто створена)
  guard: function (ctx) {
    return ctx.issue && ctx.issue.becomesReported;
  },

  action: function (ctx) {
    try {
      var issue = ctx.issue;

      // Побудова ID заявки (PROJECT-123)
      var prjShort = (issue.project && (issue.project.shortName || issue.project.name)) || '';
      var computedId = issue.idReadable ||
        (prjShort && issue.numberInProject != null ? (prjShort + '-' + issue.numberInProject) : '') ||
        (issue.id != null ? String(issue.id) : '');

      // Автор заявки (фулнейм або логін)
      var author = (issue.reporter && (issue.reporter.fullName || issue.reporter.login)) || '';

      // Спроба отримати статус з локалізованого або англійського поля
      var status = '';
      try { if (issue.fields['Статус'] && issue.fields['Статус'].name) status = String(issue.fields['Статус'].name); } catch(e){}
      if (!status) { try { if (issue.fields.State && issue.fields.State.name) status = String(issue.fields.State.name); } catch(e){} }

      // Пошук поля виконавця серед можливих варіантів (один або кілька)
      var assignee = null;
      var assigneeKeys = ['Assignee', 'Assignees', 'Виконавець', 'Виконавці'];
      for (var k = 0; k < assigneeKeys.length && !assignee; k++) {
        try {
          var label = pickAssigneeLabel(issue.fields[assigneeKeys[k]]);
          if (label) assignee = label;
        } catch(e){}
      }
      if (!assignee) assignee = '[не призначено]';

      // Формування payload для Telegram
      var payload = {
        idReadable: computedId,
        summary: issue.summary || '',
        description: issue.description || '',
        url: issue.url || '',
        author: author,
        status: status,
        assignee: assignee
      };

      // Параметри з налаштувань правила
      var baseUrl = (ctx.settings.WEBHOOK_BASE || '').replace(/\/+$/, '');
      var secret  = ctx.settings.WEBHOOK_SECRET;
      if (!baseUrl || !secret) {
        console.log('yt2tg: missing baseUrl or secret');
        return;
      }

      // Відправка POST-запиту через Bearer токен
      var conn = new http.Connection(baseUrl);
      conn.addHeader('Content-Type', 'application/json');
      conn.bearerAuth(secret);

      var res = conn.postSync('/youtrack', [], JSON.stringify(payload));
      var code = (res && (res.status != null ? res.status : res.responseCode));
      console.log('yt2tg: status=' + code + ' body=' + (res && String(res.response).slice(0, 200)));
    } catch (e) {
      console.log('yt2tg: exception: ' + e);
    }
  },

  requirements: {}
});
