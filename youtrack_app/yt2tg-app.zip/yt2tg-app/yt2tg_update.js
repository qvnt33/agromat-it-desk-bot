/**
 * YouTrack → Telegram Webhook (оновлення)
 *
 * Цей скрипт надсилає оновлення задачі у Telegram при зміні будь-якого з важливих полів:
 * - summary, description, статус (State/Статус), виконавець (Assignee/Виконавець)
 * - Пропускає зміну статусу з "Нова" – щоб уникнути дублю з create-правилом
 */

var entities = require('@jetbrains/youtrack-scripting-api/entities');
var http = require('@jetbrains/youtrack-scripting-api/http');

var WATCHED_FIELDS = ['summary', 'description', 'State', 'Статус', 'Assignee', 'Виконавець'];

// окрема функція для отримання попереднього значення поля-статусу
function prevName(issue, fieldName) {
  try {
    var prev = issue.fields.oldValue(fieldName);
    return String((prev && (prev.name || prev.localizedName || prev.presentation)) || '').toLowerCase();
  } catch (e) { return ''; }
}

// отримання текстового статусу
function pickStatus(issue) {
  try { if (issue.fields['Статус'] && issue.fields['Статус'].name) return String(issue.fields['Статус'].name); } catch (e) {}
  try { if (issue.fields.State && issue.fields.State.name) return String(issue.fields.State.name); } catch (e) {}
  return '';
}

// формування імені(імен) виконавця
function pickAssigneeLabel(val) {
  if (!val) return null;
  if (Array.isArray(val)) {
    var names = [];
    for (var i = 0; i < val.length; i++) {
      var u = val[i];
      if (u && (u.fullName || u.login || u.name)) names.push(String(u.fullName || u.login || u.name));
    }
    return names.length ? names.join(', ') : null;
  }
  return String(val.fullName || val.login || val.name || '');
}

exports.rule = entities.Issue.onChange({
  title: 'Issue updated – send full payload',

  guard: function (ctx) {
    var issue = ctx.issue;
    if (!issue || issue.becomesReported) return false;

    // чи змінилось щось з переліченого
    var changed = WATCHED_FIELDS.some(function (field) {
      try { return issue.isChanged(field); } catch (e) { return false; }
    });
    if (!changed) return false;

    // пропускаємо перехід з "Нова"
    var prev = prevName(issue, 'State') || prevName(issue, 'Статус');
    var nowNew = prev === 'нова' || prev === 'new';
    if (nowNew && (issue.isChanged('State') || issue.isChanged('Статус'))) return false;

    return true;
  },

  action: function (ctx) {
    try {
      var issue = ctx.issue;

      var prjShort = (issue.project && (issue.project.shortName || issue.project.name)) || '';
      var computedId = issue.idReadable ||
        (prjShort && issue.numberInProject != null ? (prjShort + '-' + issue.numberInProject) : '') ||
        (issue.id != null ? String(issue.id) : '');

      // визначення виконавця
      var assignee = null;
      for (var k = 0; k < WATCHED_FIELDS.length && !assignee; k++) {
        var key = WATCHED_FIELDS[k];
        if (key === 'Assignee' || key === 'Виконавець') {
          try {
            var label = pickAssigneeLabel(issue.fields[key]);
            if (label) assignee = label;
          } catch (e) {}
        }
      }
      if (!assignee) assignee = '[не призначено]';

      var changed = WATCHED_FIELDS.filter(function (name) {
        try { return issue.isChanged(name); } catch (e) { return false; }
      });

      var payload = {
        idReadable: computedId,
        summary: issue.summary || '',
        description: issue.description || '',
        url: issue.url || '',
        author: (issue.reporter && (issue.reporter.fullName || issue.reporter.login)) || '',
        status: pickStatus(issue),
        assignee: assignee,
        changes: changed,
      };

      var baseUrl = (ctx.settings.WEBHOOK_BASE || '').replace(/\/+$/, '');
      var secret = ctx.settings.WEBHOOK_SECRET;
      if (!baseUrl || !secret) {
        console.log('yt2tg-update: missing baseUrl or secret');
        return;
      }

      var conn = new http.Connection(baseUrl);
      conn.addHeader('Content-Type', 'application/json');
      conn.bearerAuth(secret);

      var res = conn.postSync('/youtrack/update', [], JSON.stringify(payload));
      var code = (res && (res.status != null ? res.status : res.responseCode));
      console.log('yt2tg-update: status=' + code + ' changed=' + changed.join(','));
    } catch (e) {
      console.log('yt2tg-update: exception: ' + e);
    }
  },

  requirements: {}
});
