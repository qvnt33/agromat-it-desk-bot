var entities = require('@jetbrains/youtrack-scripting-api/entities');
var http = require('@jetbrains/youtrack-scripting-api/http');

exports.rule = entities.Issue.onChange({
  title: 'Issue updated – send update webhook',
  guard: function (ctx) {
    var issue = ctx.issue;
    if (!issue) return false;  // немає задачі – немає події

    if (issue.becomesReported) return false;  // не реагуємо на створення – є окреме правило

    // зміни ключових полів статусу
    var stateChanged = issue.isChanged('State') || issue.isChanged('Статус');  // підтримка локалізації

    // зміни виконавця
    var assigneeChanged = issue.isChanged('Assignee') || issue.isChanged('Виконавець');  // single-user поле

    return stateChanged || assigneeChanged;  // тригеримо лише за потреби
  },

  action: function (ctx) {
    try {
      var issue = ctx.issue;

      // формуємо читабельний ID
      var prjShort = (issue.project && (issue.project.shortName || issue.project.name)) || '';
      var computedId = issue.idReadable ||
        (prjShort && issue.numberInProject != null ? (prjShort + '-' + issue.numberInProject) : '') ||
        (issue.id != null ? String(issue.id) : '');

      var author = (issue.reporter && (issue.reporter.fullName || issue.reporter.login)) || '';  // автор заявки

      // дістаємо статус із локалізованого або системного поля
      function pickStatus() {
        try { if (issue.fields['Статус'] && issue.fields['Статус'].name) return String(issue.fields['Статус'].name); } catch (e) {}
        try { if (issue.fields.State && issue.fields.State.name) return String(issue.fields.State.name); } catch (e) {}
        return '';  // fallback
      }

      // уніфікуємо представлення виконавця
      function pickAssigneeLabel(val) {
        if (!val) return null;
        if (Array.isArray(val)) {
          var names = [];
          for (var i = 0; i < val.length; i++) {
            var u = val[i];
            if (u && (u.fullName || u.login || u.name)) names.push(String(u.fullName || u.login || u.name));
          }
          return names.length ? names.join(', ') : null;  // для мультиполя, якщо зʼявиться
        }
        return String(val.fullName || val.login || val.name || '');  // single
      }

      // читаємо з можливих назв полів проєкту
      var assignee = null;
      var assigneeKeys = ['Assignee', 'Виконавець'];  // у твоєму проєкті мультиполя немає
      for (var k = 0; k < assigneeKeys.length && !assignee; k++) {
        try {
          var fld = issue.fields[assigneeKeys[k]];
          var label = pickAssigneeLabel(fld);
          if (label) assignee = label;  // беремо перше знайдене
        } catch (e) {}
      }
      if (!assignee) assignee = '[не призначено]';  // дефолт

      // дані для бекенду Telegram
      var payload = {
        idReadable: computedId,
        summary: issue.summary || '',
        description: issue.description || '',
        url: issue.url || '',
        author: author,
        status: pickStatus(),
        assignee: assignee
      };

      // налаштування з Workflow settings
      var baseUrl = (ctx.settings.WEBHOOK_BASE || '').replace(/\/+$/, '');  // прибираємо кінцеві слеші
      var secret  = ctx.settings.WEBHOOK_SECRET;  // Bearer токен
      if (!baseUrl || !secret) { console.log('yt2tg-update: missing baseUrl or secret'); return; }  // fail-soft

      // синхронний POST на бекенд
      var conn = new http.Connection(baseUrl);
      conn.addHeader('Content-Type', 'application/json');  // JSON пейлоад
      conn.bearerAuth(secret);  // авторизація

      var res = conn.postSync('/youtrack/update', [], JSON.stringify(payload));  // виклик ендпойнта
      var code = (res && (res.status != null ? res.status : res.responseCode));  // крос-версійно
      console.log('yt2tg-update: status=' + code + ' body=' + (res && String(res.response).slice(0,200)));  // короткий лог
    } catch (e) {
      console.log('yt2tg-update: exception: ' + e);  // не валимо транзакцію
    }
  },

  requirements: {}  // без жорстких привʼязок до полів – гнучкіше між проєктами
});
